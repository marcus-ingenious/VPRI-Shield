/***************************************************************************
 *  VPRI Shield Base Code                                                                                                                            
 *  Program code to control all assembly parts of the VPRI Shield.    
 *  Copyright 2017 Marcus Heinzel
 *
 *  This file is part of the VPRI Shield Base Code.
 * 
 *  The VPRI Shield Base Code is free software: you can redistribute it 
 *  and/or modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation, either version 3 of the 
 *  License, or (at your option) any later version.
 *
 *  The VPRI Shield Base Code is distributed in the hope that it will 
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty 
 *  of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with the the VPRI Shield Base Code.  
 *  If not, see <http://www.gnu.org/licenses/>.
 *************************************************************************/

 /*************************************************************
 * File:        vpri_tools.cpp                               
 * Description: Tools to control VPRI Shield assembly parts
 *************************************************************/


/*************************************************************
 * function updateButton                                     
 * 
 * Description: Evaluate and return button event for a      
 *   given digital pin based on function digitalRead().      
 *   Available events are "pressed", "hold", "released". The 
 *   current status is evaluated in comparison with          
 *   parameter oldStatus. Parameter oldStatus is updated     
 *   with the new status.                                    
 *   
 * Parameters:                                               
 *   buttonPin - button pin to be evaluated                   
 *   &oldStatus - previous event of the button               
 ************************************************************/
unsigned short updateButton(int buttonPin, bool &oldStatus);


/*************************************************************
 * function validateButtonEvent                              
 * 
 * Description: Checks if the event-status of a button       
 *   comprises a given reference event. The result is        
 *   returned as a bool value.                               
 *  
 * Parameters:                                               
 *   buttonEvent    - Event-status of a button pin            
 *   referenceEvent - Constant for a button event value      
 *************************************************************/
//reference events
const unsigned short buttonPressedEvent = 1;
const unsigned short buttonHoldEvent = 2;
const unsigned short buttonReleasedEvent = 4;
bool validateButtonEvent(unsigned short buttonEvent, unsigned short referenceEvent);


/*************************************************************
 * function getLineVoltage                                   
 * 
 * Description: Returns the calculated voltage for the       
 *   measured value on the smaller resistor on a voltage     
 *   divider.                                                
 *                                                           
 *   Note: To increase the accuracy of the MCUs voltage      
 *   measurement capabilities to an acceptable level it is   
 *   crucial to measure the exact Ohm-values of the voltage  
 *   dividers resistors with an Ohm-meter!                   
 *                                                           
 *   Note: Proper dimensioning of the resistors of           
 *   course is crucial to avoid damage to the hardware!      
 *                                                           
 * Parameters:                                               
 *   analogLine    - Analog pin to be evaluated               
 *   bigR_Ohm      - Resistor value of resistor to drop      
 *                   voltage from the voltage source to a    
 *                   technically measurable level             
 *   smallR_Ohm    - Resistors value of the resistor which   
 *                   is used to measure a voltage            
 *************************************************************/
float getLineVoltage(unsigned short analogLine, int bigR_Ohm, int smallR_Ohm);


/*************************************************************
 * function beep                                             
 * 
 * Description: Plays a piezzo buzzer beep                   
 * 
 * Parameters:                                               
 *   buzzerPin  - Buzzer pin                                  
 *   frequency  - Sound frequency in Hertz                   
 *   delayTime  - Play time                                  
 ************************************************************/
void beep(unsigned short buzzerPin, int frequency, int delayTime);


