/***************************************************************************
 *  VPRI Shield Base Code                                                                                                                            
 *  Program code to control all assembly parts of the VPRI Shield.    
 *  Copyright 2017 Marcus Heinzel
 *
 *  This file is part of the VPRI Shield Base Code.
 * 
 *  The VPRI Shield Base Code is free software: you can redistribute it 
 *  and/or modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation, either version 3 of the 
 *  License, or (at your option) any later version.
 *
 *  The VPRI Shield Base Code is distributed in the hope that it will 
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty 
 *  of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with the the VPRI Shield Base Code.  
 *  If not, see <http://www.gnu.org/licenses/>.
 *************************************************************************/

/*************************************************************
 * File:        vpri_tools.cpp                               
 * Description: Tools to control VPRI Shield assembly parts
 *                                                           
 * The documentation of the functions can be found in        
 * the header file vpri_tools.h.                             
 *************************************************************/

#include "vpri_tools.h"
#include "Arduino.h"

unsigned short updateButton(int buttonPin, bool &oldStatus) {
  // Return values bit-mask (multiple selections possible):
  // 0000 (0) = No event
  // 0001 (1) = Button pressed
  // 0010 (2) = Button hold
  // 0100 (4) = Button released
  unsigned short returnValue = 0;

  bool button = digitalRead(buttonPin);
  if (button == HIGH) {
    if (oldStatus == LOW) {
      delay(15); //debounce delay
      button = digitalRead(buttonPin);  //check if button is still LOW after debounce
      if (button == HIGH) {
        oldStatus = button;
        returnValue = buttonPressedEvent | buttonHoldEvent; 
      }
    }
    else if (oldStatus == HIGH) {
      returnValue = buttonHoldEvent; 
    }
  }
  else if (button == LOW && oldStatus == HIGH) {
    returnValue = buttonReleasedEvent;
    oldStatus = button;
  }

  return returnValue;
}

bool validateButtonEvent(unsigned short buttonEvent, unsigned short referenceEvent) {
  if ((buttonEvent & referenceEvent) == referenceEvent) return true;
  return false;
}

float getLineVoltage(unsigned short analogLine, int bigR_Ohm, int smallR_Ohm) {
  int batteryMeasurement = analogRead(analogLine);

  // 5 = 5V reference voltage, 1024 = analog value of reference voltage
  float smallR_U =  5 * batteryMeasurement / 1024.0;

  //voltage divider resistor ratio
  return (float) (bigR_Ohm + smallR_Ohm) / smallR_Ohm * smallR_U;
}

void beep(unsigned short buzzerPin, int frequency, int delayTime)
{
  tone(buzzerPin, frequency, delayTime);
  delay(delayTime);
  noTone(buzzerPin);
}




